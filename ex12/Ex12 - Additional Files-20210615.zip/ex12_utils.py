def is_valid_path(board, path, words):
    pass

def find_length_n_paths(n, board, words):
    pass

def find_length_n_words(n, board, words):
    pass

def max_score_paths(board, words):
    pass
